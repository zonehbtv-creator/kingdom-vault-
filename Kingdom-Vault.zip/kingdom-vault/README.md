# Kingdom Vault

Your personal treasury of dreams, prophetic words, Kingdom quests, and spiritual impact.

**Store up treasures in heaven.**

---

## What is included

| Feature | Route | Description |
|---------|-------|-------------|
| Landing Page | `/` | Beautiful introduction to Kingdom Vault |
| Dashboard | `/dashboard` | Overview of your Vault |
| Dream Court | `/dream-court` | Submit dreams → AI Scripture draft → community path |
| Kingdom Quests | `/quests` | Daily spiritual challenges |
| Giving Impact | `/impact` | Real testimonies of Kingdom impact |
| Personal Vault | `/vault` | Where everything is stored |

---

## How to run it (2 minutes)

### Option 1 – On your computer

1. Make sure you have **Node.js 18+** installed  
   (Download from https://nodejs.org if needed)

2. Open a terminal in this folder and run:

```bash
npm install
npm run dev
```

3. Open your browser and go to:  
   **http://localhost:3000**

### Option 2 – Fastest (no install on your machine)

1. Go to https://stackblitz.com
2. Drag and drop this entire `kingdom-vault` folder into the page
3. It installs and runs automatically
4. On your phone, open the preview link → “Add to Home Screen”

### Option 3 – Permanent free link (recommended)

1. Create a free account at https://vercel.com
2. Click “Add New Project” and import this folder
3. Deploy (about 60 seconds)
4. You get a real URL you can open and install on any phone

---

## Install on your phone (PWA)

The app is already prepared as a Progressive Web App.

- **Android**: Open in Chrome → menu (⋮) → “Add to Home screen”
- **iPhone**: Open in Safari → Share button → “Add to Home Screen”

It will appear with its own icon and open full-screen like a native app.

---

## Project structure

```
kingdom-vault/
├── public/
│   └── manifest.json          ← PWA config
├── src/
│   └── app/
│       ├── layout.tsx         ← Global layout + PWA meta
│       ├── globals.css        ← Purple/Gold design system
│       ├── page.tsx           ← Landing page
│       ├── dashboard/         ← Main dashboard
│       ├── dream-court/       ← Dream submission + interpretation
│       ├── quests/            ← Daily Kingdom Quests
│       ├── impact/            ← Giving Impact Stories
│       └── vault/             ← Personal Vault
└── package.json
```

---

## Next features we can add together

- Real AI dream interpretation (using the exact Scripture-only style you shared)
- User accounts and permanent vault storage
- Community voting in Dream Court
- Minister approval dashboard
- Offline support
- Daily quest notifications
- Real giving / NGO partnership integration

---

Built for the body of Christ.
