import Link from "next/link";

export default function DashboardPage() {
  return (
    <div className="min-h-screen kv-bg">
      {/* Top Bar */}
      <header className="border-b border-kv-gold-500/10 px-6 py-4 flex items-center justify-between max-w-6xl mx-auto">
        <Link href="/" className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-kv-gold-400 to-kv-gold-500 flex items-center justify-center">
            <span className="text-kv-purple-950 font-bold">✝</span>
          </div>
          <span className="font-bold kv-gold-text">KINGDOM VAULT</span>
        </Link>
        <div className="text-sm text-kv-gold-200/60">Welcome, Believer</div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">
        <h1 className="text-3xl font-bold mb-2">
          Your <span className="kv-gold-text">Vault</span>
        </h1>
        <p className="text-kv-gold-200/60 mb-10">
          Everything God has entrusted to you, stored in one sacred place.
        </p>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: "Dreams Stored", value: "0" },
            { label: "Quests Completed", value: "0" },
            { label: "Vault Points", value: "0" },
            { label: "Impact Stories", value: "0" },
          ].map((stat) => (
            <div key={stat.label} className="kv-card rounded-xl p-5 text-center">
              <div className="text-2xl font-bold kv-gold-text">{stat.value}</div>
              <div className="text-xs text-kv-gold-200/50 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Link
            href="/dream-court"
            className="kv-card rounded-2xl p-6 hover:scale-[1.02] transition-transform block"
          >
            <div className="text-3xl mb-3">🌙</div>
            <h2 className="text-xl font-semibold text-kv-gold-300 mb-2">Dream Court</h2>
            <p className="text-sm text-kv-gold-200/60">
              Submit a new dream or review interpretations awaiting the Court.
            </p>
          </Link>

          <Link
            href="/quests"
            className="kv-card rounded-2xl p-6 hover:scale-[1.02] transition-transform block"
          >
            <div className="text-3xl mb-3">⚔️</div>
            <h2 className="text-xl font-semibold text-kv-gold-300 mb-2">Kingdom Quests</h2>
            <p className="text-sm text-kv-gold-200/60">
              Receive and complete your daily Kingdom assignment.
            </p>
          </Link>

          <Link
            href="/impact"
            className="kv-card rounded-2xl p-6 hover:scale-[1.02] transition-transform block"
          >
            <div className="text-3xl mb-3">🌱</div>
            <h2 className="text-xl font-semibold text-kv-gold-300 mb-2">Impact Stories</h2>
            <p className="text-sm text-kv-gold-200/60">
              See how the Kingdom is moving through real giving and testimonies.
            </p>
          </Link>

          <Link
            href="/vault"
            className="kv-card rounded-2xl p-6 hover:scale-[1.02] transition-transform block"
          >
            <div className="text-3xl mb-3">🏦</div>
            <h2 className="text-xl font-semibold text-kv-gold-300 mb-2">My Vault</h2>
            <p className="text-sm text-kv-gold-200/60">
              View everything stored: dreams, quests, points, and impact.
            </p>
          </Link>
        </div>

        {/* Recent Activity Placeholder */}
        <section className="mt-14">
          <h2 className="text-xl font-semibold text-kv-gold-300 mb-4">Recent in Your Vault</h2>
          <div className="kv-card rounded-2xl p-8 text-center text-kv-gold-200/40">
            Your vault is ready. Submit your first dream or complete a quest to begin filling it.
          </div>
        </section>
      </main>
    </div>
  );
}
