"use client";

import { useState } from "react";
import Link from "next/link";

export default function DreamCourtPage() {
  const [dreamText, setDreamText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showDraft, setShowDraft] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dreamText.trim()) return;

    setIsSubmitting(true);
    // Simulate AI processing for now
    await new Promise((r) => setTimeout(r, 1800));
    setIsSubmitting(false);
    setShowDraft(true);
  };

  return (
    <div className="min-h-screen kv-bg">
      {/* Header */}
      <header className="border-b border-kv-gold-500/10 px-6 py-4 flex items-center justify-between max-w-4xl mx-auto">
        <Link href="/dashboard" className="text-kv-gold-300 hover:text-kv-gold-400 text-sm">
          ← Back to Vault
        </Link>
        <span className="font-bold kv-gold-text text-lg">Dream Court</span>
        <div className="w-16"></div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        {!showDraft ? (
          <>
            <div className="text-center mb-10">
              <div className="text-4xl mb-4">🌙</div>
              <h1 className="text-3xl font-bold mb-3">
                Bring Your Dream <span className="kv-gold-text">Before the Court</span>
              </h1>
              <p className="text-kv-gold-200/60 max-w-xl mx-auto">
                Write the dream as accurately as you remember it. The Court will prepare 
                a Scripture-rooted interpretation for community wisdom and ministerial covering.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="kv-card rounded-2xl p-6 md:p-8">
              <label className="block text-sm font-medium text-kv-gold-300 mb-3">
                Describe your dream
              </label>
              <textarea
                value={dreamText}
                onChange={(e) => setDreamText(e.target.value)}
                placeholder="I was standing among tall ladies at a gathering... (write everything you remember — people, places, feelings, colors, actions)"
                className="w-full h-56 bg-kv-purple-900/50 border border-kv-gold-500/20 rounded-xl px-4 py-3 text-white placeholder:text-kv-gold-200/30 focus:outline-none focus:border-kv-gold-500/50 resize-none"
                required
              />
              <div className="mt-4 flex items-center justify-between">
                <p className="text-xs text-kv-gold-200/40">
                  Private until you choose to submit to the Court
                </p>
                <button
                  type="submit"
                  disabled={isSubmitting || !dreamText.trim()}
                  className="kv-btn-primary px-6 py-2.5 rounded-full text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Preparing Interpretation..." : "Submit to Dream Court"}
                </button>
              </div>
            </form>

            <div className="mt-8 text-center text-sm text-kv-gold-200/40">
              <p>All interpretations are grounded in Scripture alone (Joseph & Daniel model).</p>
              <p className="mt-1">Human ministers give final approval before anything is sealed.</p>
            </div>
          </>
        ) : (
          /* Draft Interpretation View */
          <div className="space-y-8">
            <div className="text-center">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-kv-gold-500/10 border border-kv-gold-500/30 text-kv-gold-300 text-sm mb-4">
                <span className="w-2 h-2 rounded-full bg-kv-gold-400"></span>
                Draft Ready for Review
              </div>
              <h1 className="text-2xl font-bold">Scripture-Based Interpretation</h1>
              <p className="text-kv-gold-200/50 text-sm mt-2">
                This is an AI-assisted draft. It will now go to community voting and ministerial approval.
              </p>
            </div>

            <div className="kv-card rounded-2xl p-6 md:p-8 space-y-6">
              <div>
                <h3 className="text-kv-gold-400 font-medium mb-2">Your Dream (summary)</h3>
                <p className="text-kv-gold-200/70 text-sm leading-relaxed whitespace-pre-wrap">
                  {dreamText.slice(0, 300)}
                  {dreamText.length > 300 ? "..." : ""}
                </p>
              </div>

              <hr className="border-kv-gold-500/15" />

              <div>
                <h3 className="text-kv-gold-400 font-medium mb-3">Prophetic Interpretation</h3>
                <div className="prose prose-invert max-w-none text-kv-gold-200/80 text-sm leading-relaxed space-y-4">
                  <p>
                    <strong className="text-kv-gold-300">Overall theme:</strong> A season of transition, 
                    testing of associations, divine covering, unexpected deliverance, and elevation.
                  </p>
                  <p>
                    God often speaks through dreams using symbols drawn from daily life 
                    (Numbers 12:6; Job 33:14-16; Daniel 2:28). This dream unfolds in connected scenes 
                    that call for discernment and steadfastness.
                  </p>
                  <p>
                    <em className="text-kv-gold-200/50">
                      (Full detailed interpretation following the Joseph/Daniel Scripture-only method 
                      would appear here — matching the depth and structure of the example you shared earlier.)
                    </em>
                  </p>
                </div>
              </div>

              <div className="bg-kv-purple-900/40 rounded-xl p-4 border border-kv-gold-500/10">
                <h4 className="text-sm font-medium text-kv-gold-300 mb-2">Suggested Prayers</h4>
                <ul className="text-xs text-kv-gold-200/60 space-y-1">
                  <li>• Prayer for refinement and grace covering</li>
                  <li>• Prayer against compromise in associations</li>
                  <li>• Prayer for deliverance and covering in conflict</li>
                  <li>• Prayer for transition into elevation</li>
                </ul>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => {
                  setShowDraft(false);
                  setDreamText("");
                }}
                className="kv-btn-secondary px-6 py-2.5 rounded-full text-sm"
              >
                Edit Dream
              </button>
              <button className="kv-btn-primary px-6 py-2.5 rounded-full text-sm font-semibold">
                Send to Community Vote
              </button>
            </div>

            <p className="text-center text-xs text-kv-gold-200/40">
              Next step: Community members can upvote wisdom. Approved ministers give final seal.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
