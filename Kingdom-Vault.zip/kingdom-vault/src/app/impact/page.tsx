import Link from "next/link";

const SAMPLE_STORIES = [
  {
    id: 1,
    title: "Clean water reaches 40 families in rural Benue",
    location: "Otukpo, Nigeria",
    summary:
      "Through partners on the ground, a new borehole was completed last month. Children no longer walk hours for water. The community gathered to give thanks.",
    date: "2 weeks ago",
    category: "Provision",
  },
  {
    id: 2,
    title: "Young mother receives business seed capital",
    location: "Lagos, Nigeria",
    summary:
      "After completing a Kingdom entrepreneurship training, Grace received a small grant. Her food business now employs two other women from her church.",
    date: "1 month ago",
    category: "Empowerment",
  },
  {
    id: 3,
    title: "Medical outreach treats 180 people in one day",
    location: "Idoma territory",
    summary:
      "A team of Christian doctors and nurses ran a free clinic. Medicines, prayer, and follow-up care were given. Several people gave their lives to Christ.",
    date: "3 weeks ago",
    category: "Healing & Outreach",
  },
];

export default function ImpactPage() {
  return (
    <div className="min-h-screen kv-bg">
      {/* Header */}
      <header className="border-b border-kv-gold-500/10 px-6 py-4 flex items-center justify-between max-w-4xl mx-auto">
        <Link href="/dashboard" className="text-kv-gold-300 hover:text-kv-gold-400 text-sm">
          ← Back to Vault
        </Link>
        <span className="font-bold kv-gold-text text-lg">Giving Impact</span>
        <div className="w-16"></div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <div className="text-center mb-12">
          <div className="text-4xl mb-3">🌱</div>
          <h1 className="text-3xl font-bold mb-3">
            Kingdom <span className="kv-gold-text">Impact Stories</span>
          </h1>
          <p className="text-kv-gold-200/60 max-w-xl mx-auto">
            Real fruit from real giving. These are living testimonies of how resources released through the body of Christ are changing lives.
          </p>
        </div>

        {/* Featured Story */}
        <div className="kv-card rounded-2xl p-6 md:p-8 mb-10">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-kv-gold-500/15 text-kv-gold-400">
              Featured
            </span>
            <span className="text-xs text-kv-gold-200/40">{SAMPLE_STORIES[0].location}</span>
          </div>
          <h2 className="text-2xl font-semibold text-white mb-3">{SAMPLE_STORIES[0].title}</h2>
          <p className="text-kv-gold-200/70 leading-relaxed mb-4">{SAMPLE_STORIES[0].summary}</p>
          <div className="flex items-center justify-between text-sm text-kv-gold-200/40">
            <span>{SAMPLE_STORIES[0].date}</span>
            <span className="text-kv-gold-400">{SAMPLE_STORIES[0].category}</span>
          </div>
        </div>

        {/* Story Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {SAMPLE_STORIES.slice(1).map((story) => (
            <div key={story.id} className="kv-card rounded-xl p-5 hover:border-kv-gold-500/40 transition">
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs text-kv-gold-200/40">{story.location}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-kv-purple-700/50 text-kv-gold-300">
                  {story.category}
                </span>
              </div>
              <h3 className="font-semibold text-white mb-2">{story.title}</h3>
              <p className="text-sm text-kv-gold-200/60 leading-relaxed mb-4">{story.summary}</p>
              <div className="text-xs text-kv-gold-200/40">{story.date}</div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-14 kv-card rounded-2xl p-8 text-center">
          <h3 className="text-xl font-semibold text-kv-gold-300 mb-3">Want to be part of the impact?</h3>
          <p className="text-kv-gold-200/60 mb-6 max-w-md mx-auto">
            Kingdom Vault will soon connect verified giving opportunities directly to trusted partners on the field.
          </p>
          <button className="kv-btn-primary px-6 py-2.5 rounded-full text-sm font-semibold" disabled>
            Coming Soon
          </button>
        </div>
      </main>
    </div>
  );
}
