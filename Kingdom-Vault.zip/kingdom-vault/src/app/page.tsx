import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Navigation */}
      <header className="w-full px-6 py-5 flex items-center justify-between max-w-6xl mx-auto">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-kv-gold-400 to-kv-gold-500 flex items-center justify-center shadow-lg shadow-kv-gold-500/30">
            <span className="text-kv-purple-950 font-bold text-lg">✝</span>
          </div>
          <span className="text-xl font-bold kv-gold-text tracking-wide">
            KINGDOM VAULT
          </span>
        </div>
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-kv-gold-200/80">
          <Link href="#features" className="hover:text-kv-gold-400 transition">Features</Link>
          <Link href="#dream-court" className="hover:text-kv-gold-400 transition">Dream Court</Link>
          <Link href="#quests" className="hover:text-kv-gold-400 transition">Quests</Link>
          <Link href="/login" className="kv-btn-secondary px-5 py-2 rounded-full text-sm">
            Enter Vault
          </Link>
        </nav>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 pt-10 pb-20 text-center">
        <div className="max-w-3xl mx-auto space-y-8">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-kv-gold-500/30 bg-kv-purple-800/40 text-kv-gold-300 text-sm">
            <span className="w-2 h-2 rounded-full bg-kv-gold-400 animate-pulse"></span>
            Store up treasures in heaven
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight tracking-tight">
            <span className="kv-gold-text">Your Sacred Vault</span>
            <br />
            <span className="text-white/90">for Dreams, Words & Kingdom Impact</span>
          </h1>

          <p className="text-lg sm:text-xl text-kv-gold-200/70 max-w-2xl mx-auto leading-relaxed">
            Capture prophetic dreams. Receive Scripture-rooted interpretations. 
            Complete daily Kingdom Quests. Watch real giving change lives. 
            All stored securely in your personal Kingdom Vault.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link
              href="/dashboard"
              className="kv-btn-primary px-8 py-3.5 rounded-full text-base font-semibold shadow-lg"
            >
              Open Your Vault
            </Link>
            <Link
              href="#dream-court"
              className="kv-btn-secondary px-8 py-3.5 rounded-full text-base font-semibold"
            >
              See Dream Court
            </Link>
          </div>
        </div>

        {/* Feature Cards Preview */}
        <div id="features" className="mt-24 w-full max-w-5xl grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Dream Court Card */}
          <div className="kv-card rounded-2xl p-6 text-left hover:scale-[1.02] transition-transform duration-300">
            <div className="w-12 h-12 rounded-xl bg-kv-purple-700/60 flex items-center justify-center mb-4 text-2xl">
              🌙
            </div>
            <h3 className="text-xl font-semibold text-kv-gold-300 mb-2">Dream Court</h3>
            <p className="text-sm text-kv-gold-200/60 leading-relaxed">
              Submit your dream. AI drafts a pure Scripture-based interpretation. 
              The community votes. Ministers approve. Your word is sealed in the Vault.
            </p>
          </div>

          {/* Kingdom Quests Card */}
          <div className="kv-card rounded-2xl p-6 text-left hover:scale-[1.02] transition-transform duration-300">
            <div className="w-12 h-12 rounded-xl bg-kv-purple-700/60 flex items-center justify-center mb-4 text-2xl">
              ⚔️
            </div>
            <h3 className="text-xl font-semibold text-kv-gold-300 mb-2">Kingdom Quests</h3>
            <p className="text-sm text-kv-gold-200/60 leading-relaxed">
              Fresh daily challenges generated for you: pray for a city, give, encourage, 
              intercede. Build spiritual momentum one quest at a time.
            </p>
          </div>

          {/* Impact Stories Card */}
          <div className="kv-card rounded-2xl p-6 text-left hover:scale-[1.02] transition-transform duration-300">
            <div className="w-12 h-12 rounded-xl bg-kv-purple-700/60 flex items-center justify-center mb-4 text-2xl">
              🌱
            </div>
            <h3 className="text-xl font-semibold text-kv-gold-300 mb-2">Giving Impact</h3>
            <p className="text-sm text-kv-gold-200/60 leading-relaxed">
              Real stories from the field. See how Kingdom resources are changing lives. 
              Celebrate testimonies that prove the Vault is overflowing outward.
            </p>
          </div>
        </div>

        {/* Dream Court Teaser */}
        <section id="dream-court" className="mt-28 w-full max-w-4xl">
          <div className="kv-card rounded-3xl p-8 md:p-12 text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-kv-gold-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            
            <div className="relative z-10">
              <span className="text-kv-gold-400 text-sm font-medium tracking-wider uppercase">
                The Heart of the Vault
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mt-3 mb-6">
                <span className="kv-gold-text">Dream Court</span>
              </h2>
              <p className="text-kv-gold-200/70 text-lg leading-relaxed mb-8 max-w-2xl">
                God still speaks through dreams (Numbers 12:6, Job 33:14-16). 
                Kingdom Vault gives every believer a safe, Scripture-anchored place 
                to bring those dreams into the light — with wisdom, accountability, 
                and the body of Christ.
              </p>

              <div className="grid sm:grid-cols-3 gap-4 mb-8">
                <div className="bg-kv-purple-900/50 rounded-xl p-4 border border-kv-gold-500/10">
                  <div className="text-kv-gold-400 font-bold text-lg mb-1">1</div>
                  <div className="text-sm text-kv-gold-200/80">You submit the dream</div>
                </div>
                <div className="bg-kv-purple-900/50 rounded-xl p-4 border border-kv-gold-500/10">
                  <div className="text-kv-gold-400 font-bold text-lg mb-1">2</div>
                  <div className="text-sm text-kv-gold-200/80">AI drafts biblical interpretation</div>
                </div>
                <div className="bg-kv-purple-900/50 rounded-xl p-4 border border-kv-gold-500/10">
                  <div className="text-kv-gold-400 font-bold text-lg mb-1">3</div>
                  <div className="text-sm text-kv-gold-200/80">Community + Ministers seal it</div>
                </div>
              </div>

              <Link
                href="/dream-court"
                className="inline-flex items-center gap-2 kv-btn-primary px-6 py-3 rounded-full text-sm font-semibold"
              >
                Enter Dream Court →
              </Link>
            </div>
          </div>
        </section>

        {/* Quests Teaser */}
        <section id="quests" className="mt-16 w-full max-w-4xl text-left">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-4">
                Daily <span className="kv-gold-text">Kingdom Quests</span>
              </h2>
              <p className="text-kv-gold-200/70 leading-relaxed mb-6">
                Never run out of Kingdom assignments. Each day brings a fresh, 
                Spirit-led challenge designed to stretch your faith, deepen intercession, 
                and release practical love.
              </p>
              <ul className="space-y-3 text-sm text-kv-gold-200/80">
                <li className="flex items-start gap-2">
                  <span className="text-kv-gold-400 mt-0.5">✓</span>
                  Personalized and location-aware when possible
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-kv-gold-400 mt-0.5">✓</span>
                  Track completion streaks in your Vault
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-kv-gold-400 mt-0.5">✓</span>
                  Share victories and encourage others
                </li>
              </ul>
            </div>
            <div className="w-full md:w-72 kv-card rounded-2xl p-5">
              <div className="text-xs text-kv-gold-400/80 uppercase tracking-wider mb-2">Today’s Quest</div>
              <div className="text-lg font-medium text-white mb-3">
                Pray for someone in your city by name and send them an encouraging message.
              </div>
              <div className="flex items-center justify-between text-xs text-kv-gold-200/50">
                <span>Difficulty: Easy</span>
                <span>+15 Vault Points</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-kv-gold-500/10 py-8 px-6 text-center text-sm text-kv-gold-200/40">
        <p>Kingdom Vault • Store up treasures that never fade</p>
        <p className="mt-1">Built for the body of Christ • Scripture first • Always free at the core</p>
      </footer>
    </div>
  );
}
