"use client";

import { useState } from "react";
import Link from "next/link";

const SAMPLE_QUESTS = [
  {
    id: 1,
    title: "Pray for someone in your city by name",
    description: "Ask the Lord for one person in your city. Call or send them a short message of encouragement after praying.",
    difficulty: "Easy",
    points: 15,
    category: "Intercession",
  },
  {
    id: 2,
    title: "Bless a stranger with unexpected kindness",
    description: "Buy a meal, pay for someone’s transport, or leave an anonymous gift. Do it quietly and give God the glory.",
    difficulty: "Medium",
    points: 25,
    category: "Generosity",
  },
  {
    id: 3,
    title: "Intercede for a nation in the news",
    description: "Choose one nation currently facing crisis. Spend at least 10 focused minutes praying Scripture over it.",
    difficulty: "Easy",
    points: 15,
    category: "Intercession",
  },
];

export default function QuestsPage() {
  const [completed, setCompleted] = useState<number[]>([]);
  const [activeQuest, setActiveQuest] = useState(SAMPLE_QUESTS[0]);

  const markComplete = (id: number) => {
    if (!completed.includes(id)) {
      setCompleted([...completed, id]);
    }
  };

  return (
    <div className="min-h-screen kv-bg">
      {/* Header */}
      <header className="border-b border-kv-gold-500/10 px-6 py-4 flex items-center justify-between max-w-4xl mx-auto">
        <Link href="/dashboard" className="text-kv-gold-300 hover:text-kv-gold-400 text-sm">
          ← Back to Vault
        </Link>
        <span className="font-bold kv-gold-text text-lg">Kingdom Quests</span>
        <div className="text-sm text-kv-gold-200/50">{completed.length} completed</div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <div className="text-center mb-10">
          <div className="text-4xl mb-3">⚔️</div>
          <h1 className="text-3xl font-bold mb-2">
            Today’s <span className="kv-gold-text">Kingdom Quests</span>
          </h1>
          <p className="text-kv-gold-200/60 max-w-lg mx-auto">
            Fresh assignments generated daily. Complete them, grow in obedience, and store up treasure in your Vault.
          </p>
        </div>

        {/* Active Quest Highlight */}
        <div className="kv-card rounded-2xl p-6 md:p-8 mb-10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 bg-kv-gold-500/5 rounded-full blur-2xl"></div>
          <div className="relative">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-kv-gold-500/15 text-kv-gold-400">
                Featured Quest
              </span>
              <span className="text-xs text-kv-gold-200/40">{activeQuest.category}</span>
            </div>
            <h2 className="text-2xl font-semibold text-white mb-3">{activeQuest.title}</h2>
            <p className="text-kv-gold-200/70 mb-6 leading-relaxed">{activeQuest.description}</p>
            <div className="flex items-center justify-between">
              <div className="flex gap-4 text-sm text-kv-gold-200/50">
                <span>Difficulty: {activeQuest.difficulty}</span>
                <span>+{activeQuest.points} Vault Points</span>
              </div>
              <button
                onClick={() => markComplete(activeQuest.id)}
                disabled={completed.includes(activeQuest.id)}
                className={`px-5 py-2.5 rounded-full text-sm font-semibold transition ${
                  completed.includes(activeQuest.id)
                    ? "bg-green-600/30 text-green-300 cursor-default"
                    : "kv-btn-primary"
                }`}
              >
                {completed.includes(activeQuest.id) ? "Completed ✓" : "Mark Complete"}
              </button>
            </div>
          </div>
        </div>

        {/* Quest List */}
        <h3 className="text-lg font-semibold text-kv-gold-300 mb-4">More Quests Available</h3>
        <div className="space-y-4">
          {SAMPLE_QUESTS.map((quest) => (
            <div
              key={quest.id}
              className={`kv-card rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition ${
                completed.includes(quest.id) ? "opacity-60" : "hover:border-kv-gold-500/40"
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium text-white">{quest.title}</h4>
                  {completed.includes(quest.id) && (
                    <span className="text-xs text-green-400">✓ Done</span>
                  )}
                </div>
                <p className="text-sm text-kv-gold-200/50">{quest.description}</p>
                <div className="flex gap-3 mt-2 text-xs text-kv-gold-200/40">
                  <span>{quest.difficulty}</span>
                  <span>+{quest.points} pts</span>
                  <span>{quest.category}</span>
                </div>
              </div>
              <button
                onClick={() => {
                  setActiveQuest(quest);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="kv-btn-secondary px-4 py-2 rounded-full text-xs whitespace-nowrap"
              >
                View Quest
              </button>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center text-sm text-kv-gold-200/40">
          <p>New quests appear daily. Streaks and history are saved in your personal Vault.</p>
        </div>
      </main>
    </div>
  );
}
