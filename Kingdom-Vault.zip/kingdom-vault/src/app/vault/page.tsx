import Link from "next/link";

export default function VaultPage() {
  return (
    <div className="min-h-screen kv-bg">
      <header className="border-b border-kv-gold-500/10 px-6 py-4 flex items-center justify-between max-w-4xl mx-auto">
        <Link href="/dashboard" className="text-kv-gold-300 hover:text-kv-gold-400 text-sm">
          ← Back to Dashboard
        </Link>
        <span className="font-bold kv-gold-text text-lg">My Vault</span>
        <div className="w-20"></div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">
        <div className="text-center mb-12">
          <div className="text-5xl mb-4">🏦</div>
          <h1 className="text-3xl font-bold mb-2">
            Your Personal <span className="kv-gold-text">Kingdom Vault</span>
          </h1>
          <p className="text-kv-gold-200/60">
            Every dream sealed, every quest completed, every impact story that touched you — stored here.
          </p>
        </div>

        {/* Empty State for now */}
        <div className="kv-card rounded-2xl p-12 text-center">
          <p className="text-kv-gold-200/50 mb-6">
            Your vault is currently empty. Start filling it by submitting a dream or completing a quest.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dream-court" className="kv-btn-primary px-6 py-2.5 rounded-full text-sm font-semibold">
              Submit a Dream
            </Link>
            <Link href="/quests" className="kv-btn-secondary px-6 py-2.5 rounded-full text-sm font-semibold">
              View Quests
            </Link>
          </div>
        </div>

        {/* Future sections placeholders */}
        <div className="mt-12 grid md:grid-cols-3 gap-4">
          <div className="kv-card rounded-xl p-5 text-center opacity-60">
            <div className="text-2xl mb-2">🌙</div>
            <div className="text-sm font-medium text-kv-gold-300">Sealed Dreams</div>
            <div className="text-xs text-kv-gold-200/40 mt-1">0 stored</div>
          </div>
          <div className="kv-card rounded-xl p-5 text-center opacity-60">
            <div className="text-2xl mb-2">⚔️</div>
            <div className="text-sm font-medium text-kv-gold-300">Completed Quests</div>
            <div className="text-xs text-kv-gold-200/40 mt-1">0 completed</div>
          </div>
          <div className="kv-card rounded-xl p-5 text-center opacity-60">
            <div className="text-2xl mb-2">🌱</div>
            <div className="text-sm font-medium text-kv-gold-300">Impact Touched</div>
            <div className="text-xs text-kv-gold-200/40 mt-1">0 stories</div>
          </div>
        </div>
      </main>
    </div>
  );
}
